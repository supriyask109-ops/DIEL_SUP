const CACHE="diel-sup-v1";
const FILES=["./","./index.html","./style.css","./app.js","./manifest.webmanifest","./data/materials.json","./icons/icon.svg","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener("activate",event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",event=>{
 const req=event.request;
 if(req.method!=="GET")return;
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{
  const copy=res.clone();if(new URL(req.url).origin===location.origin)caches.open(CACHE).then(c=>c.put(req,copy));return res;
 }).catch(()=>caches.match("./index.html"))));
});